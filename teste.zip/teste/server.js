const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Dummy user data
const users = [
  {
    login: 'usuario',
    senha: 'senha123'
  }
];

// Login endpoint
app.post('/login', (req, res) => {
  const { login, senha } = req.body;

  const user = users.find(u => u.login === login && u.senha === senha);

  if (user) {
    return res.status(200).json({ message: 'Login successful' });
  } else {
    return res.status(401).json({ message: 'Credenciais erradas' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});